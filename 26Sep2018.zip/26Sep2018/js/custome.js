//var url="http://localhost/nelson/webservice.php?";
//var url="http://pwttesting.in.net/nelson/webservice.php?";
var url="http://ual-la.com/webservice.php?";

$(document).ready(function(){	
    var href = document.location.href;
    var pagename = href.substr(href.lastIndexOf('/') + 1);
    // Left Menu Start ------------------------
    $('#left-panel').load('leftmenu.html');
    // Left Menu End ------------------------------
});
        
//Language Page Start 
function getlanguages()
{ 
    // var url="http://localhost/nelson/webservice.php?";
    var dataString="action=get_default_language";
    $.ajax({
				type: "POST",
				url: url,
				data: dataString,
				crossDomain: true,
				cache: true,
				beforeSend: function(){ 
                    //$("#languages").html('Loading...');
                },
				success: function(response){ 
                    var data = $.parseJSON(response);//parse JSON
                    if(data.data.responseCode==1)
					{

                        var languageCount = data.data.languages.length;
                        var myHtml = "";
                        var k = 1;
                        $.each(data.data.languages, function( i, item ) {
                             //alert(item.is_default);
                            if(localStorage.setlanguage==null && item.is_default==1)
                             { 
                                 localStorage.setlanguage = item.lang_code;
                                 
                             }
                            if(k==1)
                            {
                                var color = 'peach';
                                var rightimage = 'purple.png';
                            }
                            else if(k==2)
                            {
                                var color = 'purple';
                                var rightimage = 'blue.png';
                            }
                            else if(k==3)
                            {
                                var color = 'blue';
                                var rightimage = 'yellow.png';
                            }
                            else if(k==4)
                            {
                                var color = 'red';
                                var rightimage = 'red.png';
                            }
                            else if(k==5)
                            {
                                var color = 'green';
                                var rightimage = 'green.png';
                            }
                            
                          if(localStorage.setlanguage==item.lang_code){ var selecttedClass = 'active';} else{ var selecttedClass = 'unactive';  }
                            
                           myHtml += "<button  class='btn "+color+"-gradient btn-rounded' value='"+item.lang_code+"' onclick='setlanguagefun(\"" + item.lang_code + "\" )' type='button' >" + item.language + "</button><p class='myText "+selecttedClass+" ' id='right"+item.lang_code+"' ><img src='images/"+rightimage+"' class=' righticon_lanugage'></p>";
                           // alert(item.language);
                            
                           if(k==5){ k = 0;}
                           k++; 
                        });
                      //  alert(myHtml);
                        $("#languages").html(myHtml);
					}
					else if(data.data.responseCode==0)
					{
						$("#languages").html('Record not found');
						
					}
				}
			});
}
function setlanguagefun(val)
{
    localStorage.setlanguage = val;
    //alert(localStorage.setlanguage);
    $('.myText').removeClass('active');
    //$('.myText').removeClass('unactive');
    
    $('.myText').addClass('unactive');
    
    $('#right'+val).removeClass('unactive');
    $('#right'+val).addClass('active');
    
    window.location.replace('item.html?id=0');
}
//Language Page End 
function getcardsets()
{
    // var url="http://localhost/nelson/webservice.php?";
    var dataString="action=get_cardsets";
    $.ajax({
				type: "POST",
				url: url,
				data: dataString,
				crossDomain: true,
				cache: true,
				beforeSend: function(){ 
                    //$("#languages").html('Loading...');
                },
				success: function(response){ 
                    var data = $.parseJSON(response);//parse JSON
                    if(data.data.responseCode==1)
					{
                        var cardsetCount = data.data.cardset.length;
                        var myHtml = "";
                        var k = 1;
                        $.each(data.data.cardset, function( i, item ) {
                           myHtml += "<li><a href='items_slider.html?id="+item.id+"'>"+ item.title +"</a></li>";
                        });
                        $("#cardset").html(myHtml);
					}
					else if(data.data.responseCode==0)
					{
					    $("#cardset").html('<li>Card set not available</li>');
					}
				}
			});
}
//Play Start 
function getpaly(id)
{  
    var dataString="action=get_play&id="+id+"&language="+localStorage.setlanguage;
    $.ajax({
				type: "POST",
				url: url,
				data: dataString,
				crossDomain: true,
				cache: true,
				beforeSend: function(){ 
                    //$("#languages").html('Loading...');
                }, 
				success: function(response){ 
                    var data = $.parseJSON(response);//parse JSON
                    //alert(data.data.item.question);
                    if(data.data.responseCode==1)
					{
                        var myHtml = '';
                        $.each(data.data.items, function( i, item ) {
                            
                            var titlesplit = item.question.split('');
                            var k = 1;
                            var TitleHTml = '';
                            // alert(item.answer);
                            for(var i = 0; i <= titlesplit.length ; i++ )
                            {
                                if(k==1)
                                {
                                        var color = '#9b59b6';
                                }
                                else if(k==2)
                                {
                                        var color = '#6561ab';
                                }
                                else if(k==3)
                                {
                                        var color = '#4eb9f3';
                                }
                                else if(k==4)
                                {
                                        var color = '#48d2b0';
                                }
                                else if(k==5)
                                {
                                        k = 0;
                                        var color = '#ff8343';
                                }                                                                
                                if(titlesplit.length!=i)
                                {
                                    TitleHTml += "<span style='color:"+color+"'>"+titlesplit[i]+"</span>";                                   
                                }   
                                k++;
                              }      

                            myHtml += '<div class="w3-display-container mySlides">';
                            myHtml += '<ul id="stats">';
                            $.each(item.options, function(i,option) {                                  
                                if(item.answer==option.id)
                                {
                                    var optionimage = '<img src="'+data.data.URL_ROOT+'images/correct.png" style="display: none; padding-left: 30%;" >';
                                }
                                else{
                                    var optionimage = '<img src="'+data.data.URL_ROOT+'images/wrong.png" style="display: none; padding-left: 30%;">';
                                }
                                
                                myHtml += '<li class="slider_images chooseoption'+item.id+'" id="'+item.id+'"><img src="'+data.data.URL_ROOT+'uploads/items/'+option.image+'" class="responsive mar5">'+optionimage+'</li>';
                                /* myHtml += '<li class="slider_images" id="orance"><img src="images/close_righticon.png"><img src="uploads/items/'+option.image+'" class="responsive"></li>' */
                                                                
                            } );
                            myHtml += '</ul>';
                            myHtml += '<div class="w3-display-bottomleft w3-large w3-container w3-padding-16 w3-black">'+TitleHTml+'</div>';
                            myHtml += '</div>';                            
                            
                        });

                        myHtml += '<div class="w3-center">';
                        myHtml += '<div class="w3-section">';
                        myHtml += '<a onClick="plusDivs(1)"><img src="'+data.data.URL_ROOT+'images/next_buttonsingle.png"></a>';
                        myHtml += '<a onClick="plusDivs(-1)"><img src="'+data.data.URL_ROOT+'images/pervious_buttonsingle.png"></a>';
                        myHtml += '</div></div>';
                        
                      //  alert(myHtml);
                       $("#itemdiv").html(myHtml);

                       var slideIndex = 1;
                       showDivs(slideIndex);

                       function plusDivs(n) {
                       showDivs(slideIndex += n);
                      }

                        function showDivs(n) {
                            var i;
                            var x = document.getElementsByClassName("mySlides");
                            if (n > x.length) {slideIndex = 1}    
                            if (n < 1) {slideIndex = x.length}
                            for (i = 0; i < x.length; i++) {
                            x[i].style.display = "none";  
                            }
                            x[slideIndex-1].style.display = "block";  
                        }
                        $('#stats li').click( function() { 
                            $('.chooseoption'+this.id+' img').css("display", "block");
                        });
					}
					else if(data.data.responseCode==0)
					{  
						$("#itemdiv").html('Record not found');
                        // getcarditems(0);
					}
				}
			});
}
function about()
{
    var dataString="action=about&language="+localStorage.setlanguage;
    $.ajax({
            type : 'POST',
            url : url,
            data : dataString,
            crossDomain : true,
            cache : true,
            beforeSend : function () { },
            success : function (response)
            { 
                var data = $.parseJSON(response);
                if(data.data.responseCode==1)
					{
                        var myHtml = data.data.about.content;
                       //  alert(myHtml);
                       $("#itemdiv").html(''+myHtml+'');
					}
					else if(data.data.responseCode==0)
					{  
						$("#itemdiv").html('Record not found');
                        // getcarditems(0);
					}
            }
 }); 
}