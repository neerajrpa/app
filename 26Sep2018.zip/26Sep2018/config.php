<?php 
@session_start();
error_reporting(1);
if(!isset($_SESSION['language']))
{
    $_SESSION['language']='en';
}
$isset_language = $_SESSION['language'];
if($isset_language=='en')
{
	$isset_language = '';	
}
else
{
	$language_prefix = '_'.$isset_language;
}

$varAdminFolder="manage";
$varUserFolder = '';
define("DS",DIRECTORY_SEPARATOR);
define("PATH_ROOT",dirname(__FILE__));
define("PATH_LIB",PATH_ROOT.DS."library".DS);
define("PATH_ADMIN",PATH_ROOT.DS.$varAdminFolder.DS);
define("PATH_ADMIN_MODULE",PATH_ADMIN."modules".DS);
define("PATH_CLASS",PATH_ROOT.DS."classes".DS);

define("PATH_CUSTOMER",PATH_ROOT.DS.$varUserFolder.DS);
define("PATH_CUSTOMER_MODULE",PATH_CUSTOMER."modules".DS);

define("PATH_IMAGES",PATH_ROOT.DS.'images'.DS);
define("PATH_UPLOAD",PATH_ROOT.DS."uploads".DS);
define("PATH_UPLOAD_BROCHURS",PATH_UPLOAD."brochure".DS);
define("PATH_UPLOAD_PRODUCT",PATH_UPLOAD."product".DS);
define("PATH_UPLOAD_RESUME",PATH_UPLOAD."resume".DS);
define("PATH_UPLOAD_CLUB",PATH_UPLOAD."club".DS);
define("PATH_UPLOAD_DEAL",PATH_UPLOAD."deal".DS);
define("PATH_UPLOAD_CATEGORY",PATH_UPLOAD."category".DS);
define("PATH_UPLOAD_BANNER",PATH_UPLOAD."banner".DS);
define("PATH_UPLOAD_USER",PATH_UPLOAD."user".DS);
define("URL_ROOT","http://localhost/dealala/");
define("URL_CSS",URL_ROOT."css/");
define("URL_JS",URL_ROOT."js/");
define("URL_IMG",URL_ROOT."images/");
define("URL_ADMIN",URL_ROOT.$varAdminFolder."/");
define("URL_ADMIN_HOME",URL_ADMIN."index.php");
define("URL_ADMIN_CSS",URL_ADMIN."css/");
define("URL_ADMIN_ASSETS",URL_ADMIN."assets/");
define("URL_ADMIN_JS",URL_ADMIN."js/");
define("URL_ADMIN_IMG",URL_ADMIN."img/");
define("SELF",basename($_SERVER['PHP_SELF']));
define("LOGIN_USER","DEALALA");
define("DATE_FORMAT","d/m/Y");

//global variables
$_pswd_len=array(
                'min'=>6,
                'max'=>30 //put 0 for unlimited
                );

//define RegX expressions
define("REGX_MAIL","/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/");
define("REGX_URL","/^(http(s)?\:\/\/(?:www\.)?[a-zA-Z0-9]+(?:(?:\-|_)[a-zA-Z0-9]+)*(?:\.[a-zA-Z0-9]+(?:(?:\-|_)[a-zA-Z0-9]+)*)*\.[a-zA-Z]{2,4}(?:\/)?)$/i");
define("REGX_PHONE","/^[0-9\+][0-9\-\(\)\s]+[0-9]$/");
//$recPg=20; //records per page

require_once(PATH_LIB."class.database.php");
$db=new MySqlDb("localhost","root","",'dealala2');  

require_once(PATH_LIB."functions.php");
require_once(PATH_LIB."validations.php");
include(PATH_LIB."class.mailer.php");
$alert_err=array();
$alert_msg=array();



//set time zone
date_default_timezone_set("Asia/Dubai");

//For pagging Number of record in a page 
$numberOfPage=10; 

$projectname="Service Mart";

$validate=new Validation();

$careerlevel=array(
                    '1'  =>'Student/Intern',
                    '2'  =>'Junior',
                    '3'  =>'Mid-level',
                    '4'  =>'Senior',
                    '5'  =>'Manager',
                    '6'  =>'Executive/Director',
                    );

$salaryexpectation=array(
                        '1'  =>'Unspecified',
                        '2'  =>'0 - 1,999',
                        '3'  =>'2,000 - 3,999',
                        '4'  =>'4,000 - 5,999',
                        '5'  =>'6,000 - 7,999',
                        '6'  =>'8,000 - 11,999',
                        '7'  =>'12,000 - 19,999',
                        '8'  =>'20,000 - 29,999',
                        '9'  =>'30,000 - 49,999',
                        '10'  =>'50,000 - 99,999',
                        '11'  =>'100,000+',
                        );

$commitment=array(
                    '1'  =>'Full Time',
                    '2'  =>'Part Time',
                    '3'  =>'Contract',
                    '4'  =>'Temporary',
                    '5'  =>'Other',
                    );

$noticeperiod=array(
                        '1'  =>'None',
                        '2'  =>'1 week',
                        '3'  =>'2 weeks',
                        '4'  =>'3 weeks',
                        '5'  =>'1 month',
                        '6'  =>'2 months',
                        '7'  =>'More than 2 months',
                        );


$visastatus=array(
                        '1'  => 'Not Applicable',
                        '2'  => 'Business',
                        '3'  => 'Employment',
                        '4'  => 'Residence',
                        '5'  => 'Spouse',
                        '6'  => 'Student',
                        '7'  => 'Tourist',
                        '8'  => 'Visit',
                        );

$education=array(
                        '1'  => 'N/A',
                        '2'  => 'High-School / Secondary',
                        '3'  => 'Bachelors Degree',
                        '4'  => 'Masters Degree',
                        '5'  => 'PhD',
                        );
$modules = array(
                    "1"   => "Manage Category",
                    "2"   => "Manage Make",
                    "3"   => "Manage Models",
                    "4"   => "Manage Year",  
                    "5"   => "Specification Category",
                    "6"   => "Specification Attribute",
                    "7"   => "Specification Template",
                    "8"   => "Manage Users",
                    "9"   => "Manage Sub Admin",
                    "10"  => "Manage Contact Users",
                    "11"  => "Manage Newsletter",
                    "12"  => "Manage Help",
                    "13"  => "About",  
                    "14"  => "CMS",  
                    "15"  => "Testimonial",
                    
                    "16"  => "Manage Ads",
                    "17"  => "Report Ads",
                );


$current_currency = 'SDR';
?>